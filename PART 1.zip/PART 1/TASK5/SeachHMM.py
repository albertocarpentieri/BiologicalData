# Searching with HMM against database containing SwissProt human proteins

hmmsearch --domtblout hmm_search.hmmer_domtblout hmm_u90.hmm uniprot-reviewed_Homo_sapiens.fasta >hmm_search_out.hmmer_align
